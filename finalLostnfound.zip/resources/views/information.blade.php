@extends('main')
@section('content')

<div id="container">
    <div id="header"><br><br><br>
        <h1 style="text-align:center"><b><i>Information</i></b> </h1>
    </div>

    <div id="content">

        <p style="text-align: center"> <b><i>"Lost and Found"</i></b> is web based application which sole mission is to reunite the lost item with its owner.
            It helps to find out the lost items such as documents,electronic items and many more.<br>
            It is very easy to use. Firstly, the user must register the account to use this system.After the user is login
            he can view all the lost item and found item in the view table. <br>User can post or report about its lost item by filling up some
            important information such as-user name,address,lost item information like its type color etc. Admin will approve the request of the
            user than it will be placed in the view table and if anyone will find the item than the notification will be sent to the user.</p>

    </div>
    <br><br><br><br><br><br>
</div>
@endsection