<?php $__env->startSection('content'); ?>
    <?php if(Auth::check()): ?>
    <div id="header">
        <h2 style="text-align:center">Send Message</h2>
    </div>
    <div class="container-fluid">
        <div class="row">

            <div class="col-md-4 col-md-offset-4">
                <div class="panel panel-success">
                    <div class="panel-heading">Contact us <span class="glyphicon glyphicon-user"></span> </div>
                    <div class="panel-body">
                        <?php echo form($form); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
       <div class="alert alert-danger"><h3 style="text-align:center">Please Login First</h3></div>
       <div class="container-fluid">
           <div class="row">
       <div class="col-md-4 col-md-offset-4">
           <div class="panel panel-default">
               <div class="panel-heading"> Login<span class="glyphicon glyphicon-user"></span> </div>
               <div class="panel-body ">
                   <h1 style=font-size:150%;>Enter your Username and Password</h1></br>
                   <?php echo form($loginform); ?>

                   <div class="panel-footer"></div>
               </div>
           </div>
       </div> </div>
       </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>