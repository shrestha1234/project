
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="css/app.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/CSS.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <title>lost and found: <?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<div class="container" style="width:auto" >


        <div class="col-md-1">
            <image src="image/lostandfound.jpg" class="img-circle" style=" width:300px; height:80px;"/>
        </div>
        <div class="col-md-11" >
            <h1  style="text-align:center;font-family:verdana;" ><b><i>LOST AND FOUND</i></b></h1>
        </div>

    </div>

</div>
</div>
<body >

<nav class="navbar navbar-inverse">
    <div class="container-fluid">

       <?php echo $__env->make('menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</nav>
</div>
<?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>


<?php echo $__env->yieldContent('content'); ?></div>


</body>
<footer>Copyright ©lostandfound.com</footer>
</html>