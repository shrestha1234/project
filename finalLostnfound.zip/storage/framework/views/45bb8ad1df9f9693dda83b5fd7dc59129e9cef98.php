<?php $__env->startSection('title','Details'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="panel panel-default">
    <div class="container">
        <?php $__currentLoopData = $founddetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ld): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <h3><?php echo e($ld->name); ?></h3>
            <hr>
            <h5><span class="glyphicon glyphicon-time"></span> posted on:<?php echo e($ld->date); ?></h5>
            <hr>
            <h4>Title : <?php echo e($ld->title); ?></h4>
            <h4>Model : <?php echo e($ld->model); ?></h4>
            <h4>Address : <?php echo e($ld->address); ?></h4>
            <h4>Place where item was found : <?php echo e($ld->lostorfound_place); ?></h4>
            <h4>Specific Location : <?php echo e($ld->specific_location); ?></h4>
            <hr>
            <h4>Description</h4><p><?php echo e($ld->description); ?></p>
            <a href="/message">
                    <button type="button" class="btn btn-success">Claim</button></a>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            <hr>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>