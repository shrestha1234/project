<?php $__env->startSection('title','Found Posts'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-6">
    <div class="panel panel-default">
        <div class="panel-heading"><h4>Recent Found Item Posts</h4></div>
        <div class="panel-body ">
            <table class="table">
                <thead>
                <tr>
                    
                    <th>Description</th>
                    <th>Category</th>
                    <th>Date</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $lost_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retrive): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        
                        <td><?php echo e($retrive->description); ?></td>
                        <td><?php echo e($retrive->name); ?></td>
                        <td><?php echo e($retrive->date); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                </tbody>

            </table><a href="/allfoundposts">
                <button type="button" class="btn btn-success">View All</button></a>
        </div>



    </div>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>