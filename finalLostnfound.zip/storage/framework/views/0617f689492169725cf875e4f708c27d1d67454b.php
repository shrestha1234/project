<?php $__env->startSection('title','Register'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="panel panel-default"  >
                    <div class="panel-heading"><span class="glyphicon glyphicon-log-in"></span> Register </div>
                    <div class="panel-body ">

                        <?php echo form($form); ?>

                        <div class="panel-footer"></div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>