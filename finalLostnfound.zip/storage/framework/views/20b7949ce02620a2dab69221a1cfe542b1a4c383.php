<?php $__env->startSection('title','searchfound'); ?>
<?php $__env->startSection('content'); ?>
    <br><br>
    <div class="container">
        <div class="row">

            <div class="col-md-7 col-md-offset-3">
                <div class="panel panel-success">
                    <div class="panel-heading">Search Found Item</div>

                    <div class="panel-body">
                        <?php echo form($form); ?>

                        <div>
                            <?php if($searchfound): ?>
                                <table class="table">
                                    <thead>
                                    <tr>
                                        
                                        <th>Description</th>
                                        <th>Category</th>
                                        <th>Date</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $__currentLoopData = $searchfound; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retrive): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                                        <tr>
                                            <td><?php echo e($retrive->description); ?></td>
                                            <td><?php echo e($retrive->name); ?></td>
                                            <td><?php echo e($retrive->date); ?></td>
                                            <td><a href="/founddetailview?id=<?php echo e($retrive->id); ?>">
                                                    <button type="button" class="btn btn-success">Details</button></a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                    </tbody>
                                </table>
                            <?php endif; ?>
                        </div>

                    </div>
                    </div>
                    </div>
                </div>
            </div>
    <br><br><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>