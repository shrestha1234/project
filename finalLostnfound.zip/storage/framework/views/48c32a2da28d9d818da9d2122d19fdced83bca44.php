<?php
        $found=\Lost\found::getFoundData();
?>

<?php $__env->startSection('title','Login'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
<div class="row">
    <div class="col-md-9">
        <?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col-md-3">
        <div class="panel panel-default">
            <div class="panel-heading"> Login<span class="glyphicon glyphicon-user"></span> </div>
            <div class="panel-body ">
                <h1 style=font-size:150%;>Enter your Username and Password</h1></br>
                <?php echo form($form); ?>

            </div>
        </div>
    </div>
    </div>
        <div class="row">
            <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading"><h4>Recent Found Item Posts</h4></div>
                <div class="panel-body ">
                    <table class="table">
                        <thead>
                        <tr>
                            
                            <th>Description</th>
                            <th>Category</th>
                            <th>Date</th>
                        </tr>
                        </thead>
                   <tbody>

                       <?php $__currentLoopData = $found; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retrive): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                           <tr>
                           
                           <td><?php echo e($retrive->description); ?></td>
                           <td><?php echo e($retrive->name); ?></td>
                           <td><?php echo e($retrive->date); ?></td>
                           <td><a href="/founddetailview?id=<?php echo e($retrive->id); ?>">
                               <button type="button" class="btn btn-success">Details</button></a>
                      </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                   </tbody>

                    </table><a href="/allfoundposts">
                        <button type="button" class="btn btn-success">View All</button></a>
                </div>



                </div>
            </div>

            <div class="col-md-6">
                <div class="panel panel-default">
                    <div class="panel-heading"><h4>Recent Lost Item Posts</h4></div>
                    <div class="panel-body ">
                        <table class="table">
                            <thead>
                            <tr>
                                
                                <th>Description</th>
                                <th>Category</th>
                                <th>Date</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $lost_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retrive): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                    
                                    <td><?php echo e($retrive->description); ?></td>
                                    <td><?php echo e($retrive->name); ?></td>
                                    <td><?php echo e($retrive->date); ?></td>
                                    <td><a href="/lostdetailview?id=<?php echo e($retrive->id); ?>">
                                            <button type="button" class="btn btn-success">Details</button></a>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                            </tbody>
                        </table>
                        <a href="/alllostposts">
                        <button type="button" class="btn btn-success">View All</button></a>

                        </table>
                    </div>

                </div>
            </div>
        </div>

</div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>