<?php $__env->startSection('title','DashBoard'); ?>
<?php $__env->startSection('content'); ?>
<style>
    img {
        opacity: 0.8;
        filter: alpha(opacity=50);
    }

    img:hover {
        opacity: 1.0;
        filter: alpha(opacity=100);
    }
</style>
<div class="container">
    <div class="col-xs-11 col-md-12">
        <div class="row">
            <div class="col-xs-4 col-md-6">
                <h2>Report a Lost Item</h2>
                <a href="/lostitem">
                <img src="image/rl.jpg"  width="304" height="236"></a>
            </div>
            <div class="col-xs-4 col-md-6">
                <h2>Report a Found Item</h2>
                <a href="/founditem">
                <img src="image/rf.jpg" width="304" height="236"></a>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>